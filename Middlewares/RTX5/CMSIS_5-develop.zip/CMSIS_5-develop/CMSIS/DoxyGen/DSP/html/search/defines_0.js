var searchData=
[
  ['_5f_5fpackq7',['__PACKq7',['../none_8h.html#a3ebff224ad44c217fde9f530342e2960',1,'none.h']]],
  ['_5f_5fpkhbt',['__PKHBT',['../none_8h.html#aa505179349146cf6186640b4c8b47714',1,'none.h']]],
  ['_5f_5fpkhtb',['__PKHTB',['../none_8h.html#ac4be483b8d98e977a69baf4a292a76fe',1,'none.h']]],
  ['_5f_5fsimd32',['__SIMD32',['../arm__math__memory_8h.html#a9de2e0a5785be82866bcb96012282248',1,'arm_math_memory.h']]],
  ['_5f_5fsimd32_5fconst',['__SIMD32_CONST',['../arm__math__memory_8h.html#a1185d670d798aaf52eec13f0403f3407',1,'arm_math_memory.h']]],
  ['_5f_5fsimd64',['__SIMD64',['../arm__math__memory_8h.html#ad1b053da364f9fd82ca1a381df7590b6',1,'arm_math_memory.h']]],
  ['_5fsimd32_5foffset',['_SIMD32_OFFSET',['../arm__math__memory_8h.html#af0d54ec57b936994a34f073d0049ea3f',1,'arm_math_memory.h']]]
];
